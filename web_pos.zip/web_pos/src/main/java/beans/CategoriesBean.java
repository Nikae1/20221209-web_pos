package beans;

public class CategoriesBean {
private String levCode;
private String levName;


public String getLevCode() {
	return levCode;
}
public void setLevCode(String levCode) {
	this.levCode = levCode;
}
public String getLevName() {
	return levName;
}
public void setLevName(String levName) {
	this.levName = levName;
}
	
	
}
