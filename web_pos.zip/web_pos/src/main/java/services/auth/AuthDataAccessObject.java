package services.auth;

import services.DataAccessObject;

public class AuthDataAccessObject extends services.DataAccessObject{

	public AuthDataAccessObject() {
		
	}
	
	
	
}
