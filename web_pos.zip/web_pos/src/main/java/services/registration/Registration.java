package services.registration;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import beans.ActionBean;
import beans.CategoriesBean;
import beans.GroupBean;
import beans.StoreBean;

public class Registration {
	private HttpServletRequest request;
	
	
	public Registration(HttpServletRequest request) {
     this.request = request;
	}
	
	
	public ActionBean backController(int serviceCode) {
		ActionBean action = null;
		if(serviceCode == 11) {
			action = this.MemberJoinCtl();
		}else if(serviceCode ==12) {
			action = this.insStCtl();
		}else if(serviceCode == 13) { 
			action = this.RegempCtl();
		}else if(serviceCode == 10) {
			action = this.DupGroupNameCheckCtl();
		}else if(serviceCode == 2) {
			action = this.delectViewCtl();
		}else if(serviceCode == 4) {
			action = this.moveCtl();
		}else if(serviceCode == 5) {
			action = this.deleteSgCtl();
		}
		
		return action;
	}
	
	
	/* STORE테이블에 INSERT하기위한 메소드 
	 * 동시에 카테고리테이블에 직원등급을 넣어야하므로 동시에 실행
	 * */
	private ActionBean insStCtl() {
		ActionBean action = new ActionBean();
		GroupBean group = new GroupBean();
		String[][] empLev = {{"L1","그룹대표"},{"L2","상점매니저"},{"L3","직원"}};
		String message;
		
		group.setGroupCode(this.request.getParameter("groupCode"));
		/* GroupBean에 담겨있는 ArrayList<storeBean>을 이용하기 위한 구문 
		 * storeBean ---> ArrayList<storeBean>에 넣어야 하므로, 빈을 만들고 난 후 Array리스트에
		 * 담아서 GroupBean에 add한다.
		 * */
		StoreBean store = new StoreBean();
		store.setStoreCode(this.request.getParameter("storeCode"));
		store.setStoreName(this.request.getParameter("storeName"));
		store.setStoreZip(this.request.getParameter("storeZip"));
		store.setStoreAddr(this.request.getParameter("storeAddr"));
		store.setStoreAddrDetail(this.request.getParameter("storeAddrDetail"));
		store.setStorePhone(this.request.getParameter("storePhone"));
		
		ArrayList<StoreBean> storeList = new ArrayList<StoreBean>();
		storeList.add(store);
		group.setStoreInfoList(storeList);
		/* 카테고리테이블에 넣을 직원등급(분류코드)를 만드는 구문 */
		ArrayList<CategoriesBean> cb = new ArrayList<CategoriesBean>();
		for(String[] lev : empLev) {
			CategoriesBean agb = new CategoriesBean();
			agb.setLevCode(lev[0]);
			agb.setLevName(lev[1]);
			cb.add(agb);
		}
		group.getStoreInfoList().get(0).setLevInfo(cb);
		
		
		
		/* gruop에 모든 정보를 넣은 후 connection을 연결 */
		RegDataAccessObject dao = new RegDataAccessObject();
		Connection connection = dao.openConnection();
		dao.modifyTranStatus(connection, false);
		
		
		if(this.convertToBoolean(dao.insSTtable(connection, group))) {
			if(this.convertToBoolean(dao.insCategories(connection, group))) {
				
				message = this.makeMessage(group);
				this.request.setAttribute("message", message);
				this.request.setAttribute("storeCode", group.getStoreInfoList().get(0).getStoreCode());
				this.request.setAttribute("levInfo", this.makeSelectBox(group));
				action.setPage("step3.jsp");
				action.setRedirect(false);
			}
		}else {
			action.setPage("step2.jsp");
			action.setRedirect(true);
			
		}
		dao.setTransaction(true, connection);
		dao.modifyTranStatus(connection, true);
		dao.closeConnection(connection);
		
		return action;
	}
	
	
	
	
	
	
	/* Store step에 진입은 하였으나 [INS]가 이루어지지않고, 이전 페이지를 눌렀을 경우의 메소드 */
	private ActionBean deleteSgCtl() {
		ActionBean action = new ActionBean();
		GroupBean group = new GroupBean();
		ArrayList<GroupBean> groupList = null;
		
		boolean transection;
		String message; 
		
		group.setGroupName(this.request.getParameter("groupName"));
		
		RegDataAccessObject dao = new RegDataAccessObject();
		Connection connection = dao.openConnection("WEBDBA", "1234");
		dao.modifyTranStatus(connection, false);

		transection = this.convertToBoolean(dao.deleteSgtable(connection, group));		
		
		dao.setTransaction(true, connection);
		dao.modifyTranStatus(connection, true);
		dao.closeConnection(connection);
		
		if(transection) {
			action.setPage("group_step1.jsp");
			action.setRedirect(false);
		}else {
			
			message = "Error : 네트워크가 불안정합니다.";
			
			try {
				message = ("?message=")+URLEncoder.encode(message, "UTF-8");
			} catch (UnsupportedEncodingException e) {e.printStackTrace();}
				
			action.setPage("step2.jsp"+message);
			action.setRedirect(true);
			
		}
		
		
		return action;
	}
	
	/* 회원가입 첫 페이지 이동 */
	private ActionBean moveCtl() {
		ActionBean action = new ActionBean();
		String page="group_step1.jsp", message=null;
		boolean forward = false;
		
		action.setPage(page);
		action.setRedirect(forward);
		return action;
	}
	
	
	private ActionBean delectViewCtl() {
		ActionBean action = new ActionBean();
		GroupBean group = new GroupBean();
		ArrayList<GroupBean> groupList = null;
		boolean transection;
		
		/* request 안에 포함되어 있던 groupName을 group에 set하여 이용 */
		group.setGroupName(this.request.getParameter("groupName"));
		
		RegDataAccessObject dao = new RegDataAccessObject();
		Connection connection = dao.openConnection();
		dao.modifyTranStatus(connection, false);
		
		transection = this.convertToBoolean(dao.deleteView(connection, group));
		
		dao.setTransaction(true, connection);
		dao.modifyTranStatus(connection, true);
		dao.closeConnection(connection);
		
		if(transection) {
		
			/* common에서 제작한 Input값에서 name이 target이며 값이 values인 주소값을 이용하여
			 * 페이지주소를 지정한다. */
			action.setPage(this.request.getParameter("target"));
			action.setRedirect(false);
		}
		else {
			action.setPage("group_step2.jsp");
			action.setRedirect(true);
		}
		
		return action;
	}
	
	
	
	/* UniqueKey인 groupName을 이용하여, 중복검사를 한다 
	 * 하지만 다른 곳에서 시간차적으로 입력을 할 경우를 대비하여
	 * 임시 테이블에 저장한 후 STOREGROUP에 저장되도록 이중 검사를 하는 메소드
	 * */
	private ActionBean DupGroupNameCheckCtl() {
		ActionBean action = new ActionBean();
		GroupBean group = new GroupBean();
		ArrayList<GroupBean> groupList = null;
		
		//가져온 정보를 빈에 저장하여 중복체크에 사용하려한다
		group.setGroupName(this.request.getParameter("groupName"));
		
		//server와 소통하고 검사할 dao클래스를 생성자로 할당
		//통신을 위한 connection
		RegDataAccessObject dao = new RegDataAccessObject();
		Connection connection = dao.openConnection();
		dao.modifyTranStatus(connection, false);
		//Client로부터 넘어온 groupName의 중복검사
		groupList = dao.getDupGroupName(connection, group);
		
	
		
		String message;
		if(groupList == null) {
			/* 임시테이블에 INSERT하여 다른 곳에서의 이중입력을 방지 */
			if(this.convertToBoolean(dao.InsgroupNameView(connection, group))) {
				
				this.request.setAttribute("groupName", group.getGroupName());
				
				
				action.setPage("group_step2.jsp?previous="+this.getRefererPage());
				action.setRedirect(false);	
				
			}else {
				message = "Network Error:네트워크가 불안정 합니다. 잠시 후 다시 이용해주세요";
				try {
					message = ("?message=")+URLEncoder.encode(message, "UTF-8");
				} catch (UnsupportedEncodingException e) {e.printStackTrace();}
				action.setPage("group_step1.jsp"+message);
				action.setRedirect(true);
			}
		}//groupList == null
		else {
				message = "Error : 사용중인 그룹명입니다.";
				
				try {
					message = ("?message=")+URLEncoder.encode(message, "UTF-8");
				} catch (UnsupportedEncodingException e) {e.printStackTrace();}
					
				action.setPage("group_step1.jsp"+message);
				action.setRedirect(true);
			
		}
		
		dao.setTransaction(true, connection);
		dao.modifyTranStatus(connection, true);
		dao.closeConnection(connection);
		
		return action;
	}

	/* FrontController에서 serviceCode별로 분기시켜 SG테이블에 INSERT하기 위하여 만든
	 * CONTROLLER
	 * */
	private ActionBean MemberJoinCtl() {
		ActionBean action = new ActionBean();
		GroupBean group = new GroupBean();
		
		/* 1. request --> GroupBean 
		 * request의 3가지 정보를 group이라는 Bean에 담아 사용하려함.
		 * */
		group.setGroupName(this.request.getParameter("groupName"));
		group.setGroupCeo(this.request.getParameter("groupCeo"));
		group.setGroupPin(this.request.getParameter("groupPin"));
		
		/*
		 * 2-0. Variable Declaration */
		boolean transaction = false;
		ArrayList<GroupBean> groupList = null;
		/* 2. DAO Allocation & DAO Open 
		 * server와의 연결을 하기위해 dao를 생성자로 만들고 통신을 위한 connection을 연결한다.
		 * */
		RegDataAccessObject dao = new RegDataAccessObject();
		Connection connection = dao.openConnection();
		/* 2-1. Transaction Start */
		dao.modifyTranStatus(connection, false);
		/* 2-2. [INS] STOREGROUP */
		transaction = this.convertToBoolean(dao.insStoreGroup(connection, group));
		
		if(transaction) {
			transaction = this.convertToBoolean(dao.deleteView(connection, group));
			
			groupList = dao.getGroupCode(connection, group);
		}
		/* 2-3. [SEL] GROUPCODE */
		/* 2-4. Transaction End */
		dao.setTransaction(transaction, connection);
		dao.modifyTranStatus(connection, true);
		/* 2-5. DAO Close */
		dao.closeConnection(connection);
		
		/*등록이 끝난 후 step2로 넘어갈지 말지 결정하는 소스
		 *  + 이전 주소값과 Message를 추가하여 
		 * */
		
		request.setAttribute("groupName", this.request.getParameter("groupName"));
		request.setAttribute("groupCode", groupList.get(0).getGroupCode());
		action.setPage(transaction? "step2.jsp?previous="+this.getRefererPage():"step1.jsp");
		action.setRedirect(!transaction);
		
		return action;
	}

	private String makeSelectBox(Object obj) {
		StringBuffer select = new StringBuffer();	
		select.append("<select name=\"levelInfo\" class=\"trippleBox\">");
		for(CategoriesBean ct : (((GroupBean)obj).getStoreInfoList().get(0)).getLevInfo()) {
			select.append("<option value=\"" + ct.getLevCode() + "\">" + ct.getLevName() + "</option>");
		}
		select.append("</select>");
		
		return select.toString();
	}
	
	private String makeMessage(Object obj) {
		StringBuffer message = new StringBuffer();
		GroupBean group = (GroupBean)obj;
		message.append("상점등록정보:");
		message.append("[그룹코드] - " + group.getGroupCode() +"\\n");
		message.append("[그룹명] - " + group.getGroupName() +"\\n");
		message.append("[상점코드] - " + group.getStoreInfoList().get(0).getStoreCode() +"\\n");
		message.append("[상점이름] - " + group.getStoreInfoList().get(0).getStoreName());
		
		return message.toString();
	}	
	
	
	
	
	
	private ActionBean RegStoreCtl() {
 
		return null;
	}

	private ActionBean RegempCtl() {

		return null;
	}

	private ActionBean RegCategoriesCtl() {

		return null;
	}
	
	/* Convert to Boolean */
	private boolean convertToBoolean(int value) {
		return value>0? true:false;
	}

	/* Referer Page 추출 */
	private String getRefererPage() {
		
		return this.request.getHeader("referer").substring(this.request.getHeader("referer").lastIndexOf('/')+1);
	}
	
}
