/**
 * 
 */
 //서버로 전송할 데이터의 길이를 확인하여 적용성을 알려주는 function
 function lengthCheck(obj){
	const length =[["groupName",2,20],["groupCeo",2,5],["groupPin",6,6]];
	let result = null;
	
	for(let recordIdx=0; recordIdx<length.length; recordIdx++){
		if(obj.getAttribute("name") == length[recordIdx][0]){
			result = (obj.value.length >= length[recordIdx][1] && 
			          obj.value.length <= length[recordIdx][2])? true : false;
		
		break;
		}
	}
	return result;
}

function createForm(name, action, method){
	const form = document.createElement("form");
	if(name !== "") form.setAttribute("name",name);
	form.setAttribute("action",action);
	form.setAttribute("method",method);
	
	
	return form;
}
/* Input Box 생성*/
function createInputBox(type, name, value, placeholder){
	const input = document.createElement("input");
	input.setAttribute("type", type);
	input.setAttribute("name", name);
	if(value != "") input.setAttribute("value", value);
	if(placeholder != "") input.setAttribute("placeholde", placeholder);
	return input;
}


/* 페이지 이동 */
function movePage(targetPage){
	
	if(targetPage == 'group_step1.jsp'){
	const form = createForm("", "deleteSg","get");
		
	let group = [];
	group.push(document.getElementsByName("groupName")[0]) 
	form.appendChild(group[0]);	
		
	document.body.appendChild(form);
	form.submit();	
	
	}
	else {
	const form = createForm("", "MovePage", "get");
	const input = createInputBox("hidden", "target", targetPage, "");
	
	let group = [];
	group.push(document.getElementsByName("groupName")[0]) 
	form.appendChild(group[0]);

	form.appendChild(input);
	document.body.appendChild(form);
	
	form.submit();	
		
	}
}

/* Page Initialize */
function errorMessage(message){
	let ErrorMessage = message.split(":")[0];
	
	if(message != ''){
		document.getElementById("message").innerText = ErrorMessage;
		document.getElementById("messageContent").innerText = message.split(":")[1];
		document.getElementById("messageBox").style.display = "block";
	}
}

function disableMessage(){
	document.getElementById("message").innerText = "";
	document.getElementById("messageContent").innerText = "";
	document.getElementById("messageBox").style.display = "none";
}

